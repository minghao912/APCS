# To Do

- [x] Make UI w/ button grid
- [x] Play sound on button press
- [x] Change colour of button on button press
- [ ] Have a tracker at the top to display user progress
- [x] Have the computer place ships randomly on a grid
- [x] Make sure the ships do not collide
- [x] Check user's selection against grid of ships to check hit/miss
- [ ] Make a leaderboard w/ scores
