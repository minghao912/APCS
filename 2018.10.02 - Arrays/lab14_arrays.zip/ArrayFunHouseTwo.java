//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.lang.System;
import java.lang.Math;

public class ArrayFunHouseTwo
{
	//instance variables and constructors could be used, but are not really needed
	
	//goingUp() will return true if all numbers in numArray
	//are in increasing order [1,2,6,9,23]
	public static boolean goingUp(int[] numArray)
	{




	
		return true;
	}
	
	//goingDown() will return true if all numbers in numArray
	//are in decreasing order [31,12,6,2,1]
	public static boolean goingDown(int[] numArray)
	{





		
		return true;
	}
}