//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.util.Scanner;

public class Biggest
{
	//instance variable

	
	public Biggest(int size, String list)
	{
		
		
	}
	
	
	public void setNumbers(int size, String list)
	{
		//use a Scanner to chop up list
		
		//put the nums into decRay
		
		
	}


	public double getBiggest()
	{
		double biggest = Integer.MIN_VALUE;






		return biggest;
	}

	//toString method
	
}