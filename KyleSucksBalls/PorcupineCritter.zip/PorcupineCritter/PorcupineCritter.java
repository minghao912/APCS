import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.util.ArrayList;
public class PorcupineCritter extends Critter
{
    public PorcupineCritter()
    {
        setColor(Color.BLACK);
    }
    public void act()
    {
       PorcupineGrenade teehee = new PorcupineGrenade();
       Location hmm = getGrenadeLocation();
       if (hmm !=null)
       {
       teehee.putSelfInGrid(getGrid(), getGrenadeLocation());
       teehee.removeSelfFromGrid();
       teehee = null;
    }
       super.act();
       int num = (int)(Math.random()*10);
       if (num<5)
       {
           setDirection(getDirection()+90);
        }
    }
    public Location getGrenadeLocation()
    {
        int row = getLocation().getRow();
        int column = getLocation().getCol();
        if (getDirection() == 0)
        {
            column = column - 2;
        }
        else if (getDirection() == 90)
        {
            row = row + 2;
        }
        else if (getDirection() == 180)
        {
            column = column + 2;
        }
        else if (getDirection() == 270)
        {
            row = row + -2;
        }
        else
        {
            setDirection(getDirection() + 45);
        }
        Location ok = new Location(row,column);
        if (ok.getRow() < 1 || ok.getCol() < 1 || ok.getRow() > getGrid().getNumRows()-1 || ok.getCol() > getGrid().getNumCols()-1)
        {
            return null;
        }
        return ok;
    }
}