import info.gridworld.actor.*;
import info.gridworld.grid.Location;
import java.awt.Color;

public class Runner {
    public static void main(String[] args) {
        ActorWorld world = new ActorWorld();

        Actor create = new PorcupineCritter();
        world.add(new Location(5,5), create);
        world.show();
    }
}